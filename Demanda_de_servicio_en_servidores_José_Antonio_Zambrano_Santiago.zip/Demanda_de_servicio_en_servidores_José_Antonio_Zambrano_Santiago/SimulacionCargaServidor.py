#Importación de la libreria random para la utilización de números aleatorios
import random
#Importación para la creación de gráficas estáticas
import matplotlib.pyplot as plt
#Importación del módulo de animación de matplotlib para crear gráficas dinámicas
from matplotlib.animation import FuncAnimation

#Probabilidad de que cada tipo de petición sea válida
#Basado en la frecuencia relativa de cada tipo de consulta en PostgreSQL
LAMBDA_A = 0.5   #Tipo A: consultas simples SELECT — 50% de probabilidad de ser válidas
LAMBDA_B = 0.3   #Tipo B: consultas complejas JOIN — 30% de probabilidad de ser válidas
LAMBDA_C = 0.2   #Tipo C: escrituras INSERT/UPDATE — 20% de probabilidad de ser válidas

#Tasa de servicio de cada nucleo por ciclo
#Calculado para que el punto de equilibrio Q* sea el 75% de C
MU = 0.2

#Capacidad máxima del servidor
#Valor normalizado a partir de 570 TPS medidos en benchmark PostgreSQL sobre Raspberry Pi 4
#Fuente: Lambert, R. (2020). RustProof Labs Blog
C = 60

#Tamaño de paso del tiempo en segundos
#H = 1 garantiza que la fórmula de despacho int(MU * Q * H) funcione correctamente
H = 1

#Número de ciclos simulados
#480 ciclos × 1 segundo = 480 segundos = 8 minutos de operación simulada
CICLOS = 480

#Creación de las colas de recepción para cada tipo de petición
#Estas colas almacenan temporalmente las peticiones antes de ser validadas
colaRecepcionA = []
colaRecepcionB = []
colaRecepcionC = []

#Creación de cada nucleo del procesador BCM2711 de la Raspberry Pi 4
#Cada nucleo cuenta con 3 listas internas para clasificar las prioridades de las peticiones
#ALTA: peticiones críticas (U entre 0.00 y 0.15)
#MEDIA: peticiones prioritarias (U entre 0.16 y 0.39)
#BAJA: peticiones rutinarias (U entre 0.40 y 0.50)
nucleo1 = {"ALTA": [], "MEDIA": [], "BAJA": []}
nucleo2 = {"ALTA": [], "MEDIA": [], "BAJA": []}
nucleo3 = {"ALTA": [], "MEDIA": [], "BAJA": []}
nucleo4 = {"ALTA": [], "MEDIA": [], "BAJA": []}

#Lista que agrupa los 4 núcleos para poder recorrerlos con un ciclo for
nucleos = [nucleo1, nucleo2, nucleo3, nucleo4]

#Lista que almacena la carga total del sistema en cada ciclo
#Cada posición corresponde a un ciclo de tiempo — se usa para graficar Q(t)
cargaTotalXCiclo = []

#Contadores acumulativos — registran el total de peticiones válidas
#de cada tipo durante toda la simulación de 480 ciclos
totalPetsValidasA = 0
totalPetsValidasB = 0
totalPetsValidasC = 0

#Contador acumulativo del total de peticiones despachadas en toda la simulación
totalPetsAtent = 0

#Ciclo principal — se repite CICLOS veces, una por cada segundo simulado
for ciclos in range(CICLOS):

    #ETAPA 1 — LLEGADA DE PETICIONES
    #Se generan números aleatorios independientes para cada tipo de petición
    #El rango (0, 16) fue calibrado para que el sistema se aproxime a Q* = 45
    cantidadPeticioneXRevisar1 = random.randint(0, 16)
    cantidadPeticioneXRevisar2 = random.randint(0, 16)
    cantidadPeticioneXRevisar3 = random.randint(0, 16)

    #Creamos las peticiones de cada tipo y las agregamos a su cola de recepción
    #Cada petición se representa como un diccionario con tipo, valor U y prioridad
    #U y prioridad se asignan None por ahora — se completarán en la validación
    for contadorPeticiones in range(cantidadPeticioneXRevisar1):
        colaRecepcionA.append({"tipo": "A", "U": None, "prioridad": None})

    for contadorPeticiones in range(cantidadPeticioneXRevisar2):
        colaRecepcionB.append({"tipo": "B", "U": None, "prioridad": None})

    for contadorPeticiones in range(cantidadPeticioneXRevisar3):
        colaRecepcionC.append({"tipo": "C", "U": None, "prioridad": None})

    #ETAPA 2 — VALIDACIÓN DE PETICIONES
    #Se asigna un número aleatorio U ~ Uniforme(0,1) a cada petición
    #Si U <= lambda del tipo, la petición es válida y pasa a la siguiente etapa
    #Si U > lambda del tipo, la petición se descarta (no se agrega a válidas)

    #Validación tipo A — umbral 0.5
    peticionesValidasA = []
    for peticionXRevisarA in colaRecepcionA:
        U = random.uniform(0.0, 1.0)
        peticionXRevisarA["U"] = U
        if U <= LAMBDA_A:
            peticionesValidasA.append(peticionXRevisarA)

    #Validación tipo B — umbral 0.3
    peticionesValidasB = []
    for peticionXRevisarB in colaRecepcionB:
        U = random.uniform(0.0, 1.0)
        peticionXRevisarB["U"] = U
        if U <= LAMBDA_B:
            peticionesValidasB.append(peticionXRevisarB)

    #Validación tipo C — umbral 0.2
    peticionesValidasC = []
    for peticionXRevisarC in colaRecepcionC:
        U = random.uniform(0.0, 1.0)
        peticionXRevisarC["U"] = U
        if U <= LAMBDA_C:
            peticionesValidasC.append(peticionXRevisarC)

    #Contamos cuántas peticiones fueron válidas en este ciclo para cada tipo
    validas_A = len(peticionesValidasA)
    validas_B = len(peticionesValidasB)
    validas_C = len(peticionesValidasC)

    #Acumulamos en los contadores globales para el reporte final
    totalPetsValidasA += validas_A
    totalPetsValidasB += validas_B
    totalPetsValidasC += validas_C

    #ETAPA 3 — ASIGNACIÓN DE PRIORIDAD
    #Unimos todas las peticiones válidas de los 3 tipos en una sola lista
    totalPeticionesValidas = peticionesValidasA + peticionesValidasB + peticionesValidasC

    #Asignamos prioridad a cada petición según su valor U
    #El mismo U que determinó la validez determina la prioridad
    #Esto simula que las peticiones más urgentes tienen valores bajos de U
    for peticionXPriorizar in totalPeticionesValidas:
        U = peticionXPriorizar["U"]
        if 0.0 <= U <= 0.15:
            peticionXPriorizar["prioridad"] = "ALTA"    #15% de las válidas
        elif 0.16 <= U <= 0.39:
            peticionXPriorizar["prioridad"] = "MEDIA"   #24% de las válidas
        else:
            peticionXPriorizar["prioridad"] = "BAJA"    #61% de las válidas

    #Separamos las peticiones en tres listas según su prioridad
    #para luego unirlas en orden — ALTA primero, BAJA al final
    prioridadAlta  = [p for p in totalPeticionesValidas if p["prioridad"] == "ALTA"]
    prioridadMedia = [p for p in totalPeticionesValidas if p["prioridad"] == "MEDIA"]
    prioridadBaja  = [p for p in totalPeticionesValidas if p["prioridad"] == "BAJA"]

    #Lista ordenada: las peticiones de mayor prioridad se asignan primero a los núcleos
    peticionesOrdenadasXPrioridad = prioridadAlta + prioridadMedia + prioridadBaja

    #ETAPA 4 — ASIGNACIÓN A NÚCLEOS (BALANCEO DE CARGA)
    #Cada petición se asigna al núcleo con menor carga actual
    #Esto implementa la estrategia de balanceo por mínima ocupación
    for contPetsXAsignar in peticionesOrdenadasXPrioridad:

        #Contamos la carga actual de cada núcleo sumando sus tres sublistas
        totalPetsNucleo1 = len(nucleos[0]["ALTA"]) + len(nucleos[0]["MEDIA"]) + len(nucleos[0]["BAJA"])
        totalPetsNucleo2 = len(nucleos[1]["ALTA"]) + len(nucleos[1]["MEDIA"]) + len(nucleos[1]["BAJA"])
        totalPetsNucleo3 = len(nucleos[2]["ALTA"]) + len(nucleos[2]["MEDIA"]) + len(nucleos[2]["BAJA"])
        totalPetsNucleo4 = len(nucleos[3]["ALTA"]) + len(nucleos[3]["MEDIA"]) + len(nucleos[3]["BAJA"])

        #Agrupamos los totales en una lista para comparar fácilmente
        totalCargaXNucleo = [totalPetsNucleo1, totalPetsNucleo2, totalPetsNucleo3, totalPetsNucleo4]

        #Buscamos el índice del núcleo con menor carga
        #Empezamos asumiendo que el núcleo 1 (índice 0) es el menos ocupado
        minimo = totalCargaXNucleo[0]
        indice_minimo = 0

        #Comparamos con los núcleos 2, 3 y 4 (índices 1, 2, 3)
        for nucleoXVerificar in range(1, 4):
            if totalCargaXNucleo[nucleoXVerificar] < minimo:
                minimo = totalCargaXNucleo[nucleoXVerificar]
                indice_minimo = nucleoXVerificar

        #Recuperamos la prioridad de la petición actual
        prioridad = peticionXPriorizar["prioridad"]

        #Agregamos la petición a la sublista de prioridad correspondiente
        #dentro del núcleo menos ocupado
        nucleos[indice_minimo][prioridad].append(peticionXPriorizar)

    #ETAPA 5 — DESPACHO DE PETICIONES
    #Cada núcleo atiende un número de peticiones según la fórmula del método de Euler
    #El despacho respeta el orden de prioridad: ALTA → MEDIA → BAJA
    totalPeticionesAtendidas = 0

    for nucleo in nucleos:

        #Calculamos la carga total del núcleo en este ciclo
        totalPetsEnNucleo = len(nucleo["ALTA"]) + len(nucleo["MEDIA"]) + len(nucleo["BAJA"])

        #Aplicamos la fórmula de Euler para el despacho:
        #despachos = int(μ × Q_nucleo × H)
        #Con MU=0.2 y H=1: despachos = int(0.2 × Q_nucleo)
        despachos = int(MU * totalPetsEnNucleo * H)

        #Garantizamos al menos 1 despacho por ciclo si hay peticiones
        #Esto evita que el sistema se congele cuando Q_nucleo es pequeño
        if totalPetsEnNucleo > 0 and despachos == 0:
            despachos = 1

        #Despachamos en orden estricto de prioridad
        #despachos actúa como variable local al núcleo — se reinicia en cada iteración
        #pop(0) elimina y devuelve el primer elemento de la lista (el que llegó primero)

        #Primero atendemos las peticiones de ALTA prioridad
        while despachos > 0 and len(nucleo["ALTA"]) > 0:
            nucleo["ALTA"].pop(0)
            despachos -= 1
            totalPeticionesAtendidas += 1

        #Luego las de MEDIA prioridad si aún quedan despachos disponibles
        while despachos > 0 and len(nucleo["MEDIA"]) > 0:
            nucleo["MEDIA"].pop(0)
            despachos -= 1
            totalPeticionesAtendidas += 1

        #Finalmente las de BAJA prioridad
        while despachos > 0 and len(nucleo["BAJA"]) > 0:
            nucleo["BAJA"].pop(0)
            despachos -= 1
            totalPeticionesAtendidas += 1

    #Acumulamos el total despachado en toda la simulación
    totalPetsAtent += totalPeticionesAtendidas

    #ETAPA 6 — REGISTRO Y LIMPIEZA
    #Calculamos la carga total del sistema sumando todos los núcleos
    cargaTotalPeticiones = 0
    for nucleo in nucleos:
        cargaTotalPeticiones += len(nucleo["ALTA"])
        cargaTotalPeticiones += len(nucleo["MEDIA"])
        cargaTotalPeticiones += len(nucleo["BAJA"])

    #Guardamos la carga total del ciclo actual en el historial
    #Este historial se usará para graficar Q(t) al final
    cargaTotalXCiclo.append(cargaTotalPeticiones)

    #Imprimimos un reporte cada 10 ciclos para monitorear el progreso
    if (ciclos + 1) % 10 == 0:
        tiempo_actual = (ciclos + 1) * H
        print(f"─── Ciclo {ciclos+1} | Tiempo: {tiempo_actual:.1f}s ───────────────")
        print(f"  Peticiones válidas → A: {validas_A} | B: {validas_B} | C: {validas_C}")
        print(f"  Total despachadas  → {totalPeticionesAtendidas} peticiones")
        print(f"  Carga total en sistema → {cargaTotalPeticiones} peticiones")
        print()

    #Limpiamos las colas de recepción al final de cada ciclo
    #Las colas se reinician porque las peticiones no atendidas en recepción
    #se descartan — solo las válidas ya pasaron a los núcleos
    colaRecepcionA = []
    colaRecepcionB = []
    colaRecepcionC = []

#RESULTADOS FINALES — se imprimen al terminar los 480 ciclos
print("════════════════════════════════════════")
print("RESULTADOS FINALES DE LA SIMULACIÓN")
print("════════════════════════════════════════")
print(f"Ciclos simulados:        {CICLOS}")
print(f"Tiempo total simulado:   {CICLOS * H} segundos")
print(f"Carga al final:          {cargaTotalXCiclo[-1]} peticiones")
print(f"Carga promedio:          {sum(cargaTotalXCiclo) / len(cargaTotalXCiclo):.2f} peticiones")
print(f"Carga máximo:            {max(cargaTotalXCiclo)} peticiones")
print(f"Carga mínimo:            {min(cargaTotalXCiclo)} peticiones")
print(f"Q* teórico (ec. logística): 45 peticiones")
print()
print(f"Total de peticiones válidas → A: {totalPetsValidasA} | B: {totalPetsValidasB} | C: {totalPetsValidasC}")
print(f"Total de peticiones despachadas → {totalPetsAtent} peticiones")
print(f"Carga total en sistema → {cargaTotalPeticiones} peticiones")
print("════════════════════════════════════════")

#═══════════════════════════════════════════════════════
#BLOQUE DE GRÁFICAS
#═══════════════════════════════════════════════════════

#GRÁFICA DINÁMICA — muestra la evolución de Q(t) como animación
#Esto permite ver en tiempo real cómo crece la carga hasta el equilibrio

#Listas auxiliares para la animación
#tiempo_animacion y carga_animacion acumulan los puntos que se van dibujando
tiempo_animacion = []
carga_animacion  = []

#Creamos la figura y el eje de la gráfica dinámica
#figsize=(10, 5) define el tamaño en pulgadas: 10 de ancho y 5 de alto
fig, ax = plt.subplots(figsize=(10, 5))

#Creamos el objeto de línea que se irá actualizando en cada frame de la animación
#La coma al final de la asignación desempaqueta la lista que devuelve ax.plot
#Esto nos da directamente el objeto Line2D que necesitamos para actualizar
peticionesPendientes, = ax.plot([], [], linewidth=2, color='blue',
                                label='Carga simulada Q(t)')

#Configuramos los títulos y etiquetas de los ejes
ax.set_title("Carga de servicio del servidor\nRaspberry Pi 4 Model B (BCM2711)")
ax.set_xlabel("Tiempo (segundos)")
ax.set_ylabel("Peticiones pendientes")

#Línea horizontal roja punteada — marca el equilibrio teórico Q* = 45
#calculado analíticamente con la ecuación logística: Q* = C(1 - μ/λ)
plt.axhline(y=45, color='red', linestyle='--', linewidth=2,
            label='Q* = 45 (equilibrio teórico)')

#Línea horizontal naranja punteada — marca la capacidad máxima C = 60
#representa el límite físico del servidor según el benchmark de PostgreSQL
plt.axhline(y=C, color='orange', linestyle=':', linewidth=2,
            label=f'Capacidad máxima C = {C}')

#Activamos la cuadrícula horizontal para facilitar la lectura de valores
plt.grid(True, axis='y')

#Mostramos la leyenda en la esquina superior derecha
ax.legend(loc='upper right')

#Precalculamos el vector de tiempo completo para no recalcularlo en cada frame
#Contiene los valores 1, 2, 3, ..., 480 (un valor por cada ciclo simulado)
tiempo_completo = [(i + 1) * H for i in range(CICLOS)]

#Función de inicialización de la animación
#Se llama una vez antes de que empiece la animación
#Configura los límites de los ejes y limpia la línea
def init():
    #Eje X: de 0 al tiempo total simulado
    ax.set_xlim(0, CICLOS * H)
    #Eje Y: de 0 a 100 para tener margen por encima de C = 60
    ax.set_ylim(0, 100)
    #Iniciamos la línea vacía — se irá llenando en cada frame
    peticionesPendientes.set_data([], [])
    return (peticionesPendientes,)

#Función de actualización — se llama en cada frame de la animación
#contCiclos va de 0 a CICLOS-1, un valor por cada frame
def actualizar(contCiclos):
    #Calculamos el tiempo correspondiente a este frame
    nuevo_tiempo = (contCiclos + 1) * H

    #Acumulamos el tiempo y la carga de este frame en las listas de animación
    tiempo_animacion.append(nuevo_tiempo)
    carga_animacion.append(cargaTotalXCiclo[contCiclos])

    #Tomamos todos los datos hasta el frame actual del vector precalculado
    #Esto dibuja la línea desde el inicio hasta el punto actual
    x_data = tiempo_completo[:contCiclos + 1]
    y_data = cargaTotalXCiclo[:contCiclos + 1]

    #Actualizamos los datos de la línea con los nuevos puntos
    peticionesPendientes.set_data(x_data, y_data)

    #Expandimos el eje X si el tiempo actual supera el límite visible
    #Esto permite que la gráfica se desplace si la simulación es más larga
    if nuevo_tiempo > ax.get_xlim()[1]:
        ax.set_xlim(0, nuevo_tiempo + 10)

    #Forzamos el redibujado del canvas para que el cambio sea visible
    fig.canvas.draw_idle()

    return (peticionesPendientes,)

#Creamos el objeto de animación
#fig: figura donde se dibuja
#actualizar: función que se llama en cada frame
#frames=CICLOS: número total de frames — uno por cada ciclo simulado
#init_func=init: función de inicialización
#blit=False: redibuja toda la figura en cada frame (más compatible)
#interval=20: tiempo entre frames en milisegundos (20ms = 50 fps)
#repeat=False: la animación no se repite al terminar
ani = FuncAnimation(fig, actualizar, frames=CICLOS, init_func=init,
                    blit=False, interval=20, repeat=False)

#Mostramos la animación en pantalla
plt.show()

#═══════════════════════════════════════════════════════
#GRÁFICA 2 — DISTRIBUCIÓN DE PETICIONES POR NÚCLEO
#Gráfica de barras que muestra cuántas peticiones quedaron
#pendientes en cada núcleo al finalizar la simulación
#═══════════════════════════════════════════════════════

#Creamos una nueva figura para la gráfica de barras
plt.figure(figsize=(8, 5))

#Listas para almacenar los conteos y nombres de los núcleos
conteoNucleos  = []
nombresNucleos = ['Núcleo 1', 'Núcleo 2', 'Núcleo 3', 'Núcleo 4']

#Contamos cuántas peticiones quedaron pendientes en cada núcleo
#sumando las tres sublistas de prioridad de cada uno
for nucleo in nucleos:
    total = (len(nucleo["ALTA"]) +
             len(nucleo["MEDIA"]) +
             len(nucleo["BAJA"]))
    conteoNucleos.append(total)

#Posiciones numéricas de las barras en el eje X
#plt.bar necesita posiciones numéricas, no texto directamente
posiciones = [0, 1, 2, 3]

#Dibujamos las barras con un color distinto para cada núcleo
#width=0.5 define el ancho de cada barra
plt.bar(posiciones, conteoNucleos,
        color=['steelblue', 'darkorange', 'green', 'red'],
        width=0.5)

#Reemplazamos los números 0,1,2,3 del eje X por los nombres de los núcleos
plt.xticks(posiciones, nombresNucleos)

#Colocamos el número exacto encima de cada barra para facilitar la lectura
for i in range(4):
    plt.text(posiciones[i],           #posición horizontal centrada con la barra
             conteoNucleos[i] + 0.1,  #posición vertical ligeramente arriba de la barra
             str(conteoNucleos[i]),    #texto a mostrar — el número de peticiones
             ha='center',             #alineación horizontal centrada
             fontsize=11)             #tamaño de la fuente

#Configuramos título y etiquetas de los ejes
plt.title('Peticiones pendientes por núcleo al final\nRaspberry Pi 4 Model B (BCM2711)')
plt.xlabel('Núcleo del procesador')
plt.ylabel('Peticiones pendientes')

#Activamos la cuadrícula solo en el eje Y — en barras se ve más limpio así
plt.grid(True, axis='y')

#Ajustamos márgenes automáticamente para que nada quede cortado
plt.tight_layout()

#Guardamos la gráfica como imagen PNG en la carpeta del script
#dpi=150 define la resolución — suficiente para un reporte universitario
plt.savefig('grafica_nucleos.png', dpi=150)

#Mostramos la gráfica en pantalla
plt.show()