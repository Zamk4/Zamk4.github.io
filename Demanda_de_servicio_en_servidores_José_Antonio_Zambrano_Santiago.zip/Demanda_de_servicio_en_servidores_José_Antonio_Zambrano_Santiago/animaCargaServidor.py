#Importación para interactuar con el sistema operativo, como el manejo de archivos, la gestión de directorios y las variables de entorno
import os
#Importación para interactuar con el intérprete de Python, proporcionando acceso a parámetros y funciones específicas del sistema
import sys
#Importación de la libreria random para la utilización de números aleatorios
import random
#Importación para las advertencias de RuntimeWarning
import warnings

#═══════════════════════════════════════════════════════
#CONFIGURACIÓN DE ENTORNO GRÁFICO
#Estas variables de entorno resuelven problemas de
#compatibilidad con el driver gráfico en Linux/Ubuntu
#Deben establecerse ANTES de importar pygame
#═══════════════════════════════════════════════════════
os.environ['mesa_glthread'] = 'false'
os.environ['__GLX_VENDOR_LIBRARY_NAME'] = 'mesa'
os.environ['SDL_RENDER_DRIVER'] = 'software'

#Suprimimos advertencias de RuntimeWarning que genera pygame
#en algunos entornos Linux durante la inicialización
warnings.filterwarnings("ignore", category=RuntimeWarning)

#Importamos pygame — biblioteca para gráficos en tiempo real
#Permite dibujar formas, texto y animaciones frame a frame
import pygame

#═══════════════════════════════════════════════════════
#INICIALIZACIÓN DE PYGAME
#═══════════════════════════════════════════════════════

#Inicializamos todos los módulos de pygame
pygame.init()

#Inicializamos el módulo de fuentes para poder renderizar texto
pygame.font.init()

#Definimos las dimensiones de la ventana en píxeles
ANCHO = 1100
ALTO  = 650

#Creamos la ventana principal con las dimensiones definidas
pantalla = pygame.display.set_mode((ANCHO, ALTO))

#Establecemos el título de la ventana
pygame.display.set_caption('Simulador de Carga - Raspberry Pi 4 (BCM2711)')

#Creamos el reloj de pygame para controlar los FPS (frames por segundo)
reloj = pygame.time.Clock()

#Definimos las fuentes de texto en distintos tamaños
#SysFont busca la fuente en el sistema operativo
fuente_peque  = pygame.font.SysFont('Arial', 12)           #textos pequeños
fuente_media  = pygame.font.SysFont('Arial', 15, bold=True) #textos medianos en negrita
fuente_grande = pygame.font.SysFont('Arial', 22, bold=True) #textos grandes en negrita

#═══════════════════════════════════════════════════════
#PARÁMETROS MATEMÁTICOS DEL MODELO
#Mismos valores que en el script de gráficas — garantizan
#que la animación reproduce exactamente la misma simulación
#═══════════════════════════════════════════════════════
LAMBDA_A   = 0.5   #probabilidad de validación tipo A
LAMBDA_B   = 0.3   #probabilidad de validación tipo B
LAMBDA_C   = 0.2   #probabilidad de validación tipo C
MU         = 0.2   #tasa de servicio por núcleo
C          = 60    #capacidad máxima del servidor
EQUILIBRIO = 45    #punto de equilibrio teórico — se usa para alertas visuales
H          = 1     #paso de tiempo en segundos

#═══════════════════════════════════════════════════════
#CONFIGURACIÓN GEOMÉTRICA DE LOS NÚCLEOS EN PANTALLA
#═══════════════════════════════════════════════════════

#Dimensiones de cada rectángulo que representa un núcleo
NUCLEO_ANCHO = 190
NUCLEO_ALTO  = 95

#Posición X de todos los núcleos — están alineados a la derecha
X_NUCLEOS = 820

#Posiciones Y de cada núcleo — apilados verticalmente
#nucleo1 en Y=60, nucleo2 en Y=180, nucleo3 en Y=300, nucleo4 en Y=420
Y_NUCLEOS = [60, 180, 300, 420]

#═══════════════════════════════════════════════════════
#ESTRUCTURAS DE DATOS LÓGICAS
#Idénticas al script de gráficas — cada núcleo tiene
#tres sublistas para clasificar peticiones por prioridad
#═══════════════════════════════════════════════════════
nucleos = [
    {"ALTA": [], "MEDIA": [], "BAJA": []},
    {"ALTA": [], "MEDIA": [], "BAJA": []},
    {"ALTA": [], "MEDIA": [], "BAJA": []},
    {"ALTA": [], "MEDIA": [], "BAJA": []}
]

#Lista de peticiones en tránsito visual
#Cada elemento es un círculo animado que viaja de izquierda a derecha
#hacia el núcleo destino — solo tiene propósito visual, no afecta la lógica
peticiones_en_transito = []

#═══════════════════════════════════════════════════════
#CONTADORES ACUMULATIVOS
#Mismos contadores que en el script de gráficas
#═══════════════════════════════════════════════════════
totalPetsValidasA    = 0   #total de peticiones tipo A válidas en toda la simulación
totalPetsValidasB    = 0   #total de peticiones tipo B válidas
totalPetsValidasC    = 0   #total de peticiones tipo C válidas
totalPetsAtent       = 0   #total de peticiones despachadas en toda la simulación
ciclo_actual         = 0   #contador del ciclo matemático actual
max_carga_registrada = 0   #pico máximo de carga alcanzado durante la simulación

#═══════════════════════════════════════════════════════
#PALETA DE COLORES
#Todos los colores se definen como tuplas RGB (rojo, verde, azul)
#valores entre 0 y 255
#═══════════════════════════════════════════════════════
FONDO         = (18, 18, 23)    #fondo oscuro casi negro
GRIS_TEXTO    = (170, 170, 180) #texto secundario gris claro
BLANCO        = (255, 255, 255) #texto principal blanco
VERDE_OK      = (46, 204, 113)  #indicador de estado normal
AMARILLO_WARN = (241, 196, 15)  #indicador de advertencia
ROJO_CRITIC   = (231, 76, 60)   #indicador de estado crítico
COLOR_ALTA    = (231, 76, 60)   #peticiones de alta prioridad — rojo
COLOR_MEDIA   = (241, 196, 15)  #peticiones de media prioridad — amarillo
COLOR_BAJA    = (52, 152, 219)  #peticiones de baja prioridad — azul

#═══════════════════════════════════════════════════════
#CONTROL DE FRAMES Y CICLOS
#═══════════════════════════════════════════════════════

#Contador de frames totales desde el inicio de la animación
frame_count = 0

#Variable de control del bucle principal — False detiene la animación
ejecutando = True

#Número de frames de pygame por cada ciclo matemático
#Con 60 FPS y FRAMES_POR_CICLO=15: se ejecuta 1 ciclo cada 0.25 segundos reales
#Esto hace que la simulación de 480 segundos tarde ~2 minutos en pantalla
FRAMES_POR_CICLO = 15

#═══════════════════════════════════════════════════════
#BUCLE PRINCIPAL DE PYGAME
#Se repite indefinidamente a 60 FPS hasta que el usuario cierre la ventana
#Cada iteración del bucle = 1 frame de la animación
#═══════════════════════════════════════════════════════
while ejecutando:
    frame_count += 1

    #─── 1. CAPTURA DE EVENTOS ────────────────────────
    #pygame.event.get() devuelve todos los eventos pendientes
    #Si el usuario cierra la ventana (QUIT), detenemos el bucle
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            ejecutando = False

    #─── 2. LÓGICA MATEMÁTICA ─────────────────────────
    #Solo ejecutamos la lógica matemática cada FRAMES_POR_CICLO frames
    #El operador % devuelve el residuo de la división
    #Cuando frame_count es múltiplo de FRAMES_POR_CICLO → ejecutamos un ciclo
    if frame_count % FRAMES_POR_CICLO == 0:
        ciclo_actual += 1

        #ETAPA 1 — LLEGADA DE PETICIONES
        #Generamos cantidades aleatorias independientes para cada tipo
        cantidadPeticioneXRevisar1 = random.randint(0, 16)
        cantidadPeticioneXRevisar2 = random.randint(0, 16)
        cantidadPeticioneXRevisar3 = random.randint(0, 16)

        #Creamos las listas de peticiones usando comprensión de lista
        #Equivalente al bucle for del script de gráficas pero más compacto
        colaRecepcionA = [{"tipo": "A", "U": None, "prioridad": None}
                          for _ in range(cantidadPeticioneXRevisar1)]
        colaRecepcionB = [{"tipo": "B", "U": None, "prioridad": None}
                          for _ in range(cantidadPeticioneXRevisar2)]
        colaRecepcionC = [{"tipo": "C", "U": None, "prioridad": None}
                          for _ in range(cantidadPeticioneXRevisar3)]

        #ETAPA 2 — VALIDACIÓN
        #Idéntica al script de gráficas
        peticionesValidasA = []
        for peticionXRevisarA in colaRecepcionA:
            U = random.uniform(0.0, 1.0)
            peticionXRevisarA["U"] = U
            if U <= LAMBDA_A:
                peticionesValidasA.append(peticionXRevisarA)

        peticionesValidasB = []
        for peticionXRevisarB in colaRecepcionB:
            U = random.uniform(0.0, 1.0)
            peticionXRevisarB["U"] = U
            if U <= LAMBDA_B:
                peticionesValidasB.append(peticionXRevisarB)

        peticionesValidasC = []
        for peticionXRevisarC in colaRecepcionC:
            U = random.uniform(0.0, 1.0)
            peticionXRevisarC["U"] = U
            if U <= LAMBDA_C:
                peticionesValidasC.append(peticionXRevisarC)

        validas_A = len(peticionesValidasA)
        validas_B = len(peticionesValidasB)
        validas_C = len(peticionesValidasC)

        totalPetsValidasA += validas_A
        totalPetsValidasB += validas_B
        totalPetsValidasC += validas_C

        #ETAPA 3 — PRIORIDAD
        #Idéntica al script de gráficas
        totalPeticionesValidas = (peticionesValidasA +
                                  peticionesValidasB +
                                  peticionesValidasC)

        for peticionXPriorizar in totalPeticionesValidas:
            U = peticionXPriorizar["U"]
            if 0.0 <= U <= 0.15:
                peticionXPriorizar["prioridad"] = "ALTA"
            elif 0.16 <= U <= 0.39:
                peticionXPriorizar["prioridad"] = "MEDIA"
            else:
                peticionXPriorizar["prioridad"] = "BAJA"

        prioridadAlta  = [cp for cp in totalPeticionesValidas
                          if cp["prioridad"] == "ALTA"]
        prioridadMedia = [cp for cp in totalPeticionesValidas
                          if cp["prioridad"] == "MEDIA"]
        prioridadBaja  = [cp for cp in totalPeticionesValidas
                          if cp["prioridad"] == "BAJA"]

        peticionesOrdenadasXPrioridad = prioridadAlta + prioridadMedia + prioridadBaja

        #ETAPA 4 — ASIGNACIÓN A NÚCLEOS
        #Idéntica al script de gráficas
        #Adicionalmente lanzamos un círculo visual por cada petición asignada
        for contPetsXAsignar in peticionesOrdenadasXPrioridad:
            totalPetsNucleo1 = (len(nucleos[0]["ALTA"]) +
                                len(nucleos[0]["MEDIA"]) +
                                len(nucleos[0]["BAJA"]))
            totalPetsNucleo2 = (len(nucleos[1]["ALTA"]) +
                                len(nucleos[1]["MEDIA"]) +
                                len(nucleos[1]["BAJA"]))
            totalPetsNucleo3 = (len(nucleos[2]["ALTA"]) +
                                len(nucleos[2]["MEDIA"]) +
                                len(nucleos[2]["BAJA"]))
            totalPetsNucleo4 = (len(nucleos[3]["ALTA"]) +
                                len(nucleos[3]["MEDIA"]) +
                                len(nucleos[3]["BAJA"]))

            totalCargaXNucleo = [totalPetsNucleo1, totalPetsNucleo2,
                                  totalPetsNucleo3, totalPetsNucleo4]

            minimo        = totalCargaXNucleo[0]
            indice_minimo = 0
            for nucleoXVerificar in range(1, 4):
                if totalCargaXNucleo[nucleoXVerificar] < minimo:
                    minimo        = totalCargaXNucleo[nucleoXVerificar]
                    indice_minimo = nucleoXVerificar

            prioridad = contPetsXAsignar["prioridad"]

            #Agregamos la petición a la estructura lógica del núcleo
            nucleos[indice_minimo][prioridad].append(contPetsXAsignar)

            #Lanzamos un círculo visual hacia el núcleo destino
            #Este círculo es solo decorativo — la lógica ya procesó la petición
            #x=30: sale desde el lado izquierdo de la pantalla
            #y=aleatorio: posición vertical aleatoria para que no se amontonen
            #target_x, target_y: posición del núcleo destino en pantalla
            peticiones_en_transito.append({
                "x":         30,
                "y":         random.randint(60, ALTO - 180),
                "target_x":  X_NUCLEOS,
                "target_y":  Y_NUCLEOS[indice_minimo] + (NUCLEO_ALTO // 2),
                "tipo":      contPetsXAsignar["tipo"],
                "prioridad": prioridad
            })

        #ETAPA 5 — DESPACHO
        #Idéntica al script de gráficas
        totalPeticionesAtendidas = 0

        for nucleo in nucleos:
            totalPetsEnNucleo = (len(nucleo["ALTA"]) +
                                 len(nucleo["MEDIA"]) +
                                 len(nucleo["BAJA"]))

            despachos = int(MU * totalPetsEnNucleo * H)

            if totalPetsEnNucleo > 0 and despachos == 0:
                despachos = 1

            #despachos actúa como variable local al núcleo en este contexto
            #se reinicia con el valor calculado para cada núcleo

            while despachos > 0 and len(nucleo["ALTA"]) > 0:
                nucleo["ALTA"].pop(0)
                despachos -= 1
                totalPeticionesAtendidas += 1

            while despachos > 0 and len(nucleo["MEDIA"]) > 0:
                nucleo["MEDIA"].pop(0)
                despachos -= 1
                totalPeticionesAtendidas += 1

            while despachos > 0 and len(nucleo["BAJA"]) > 0:
                nucleo["BAJA"].pop(0)
                despachos -= 1
                totalPeticionesAtendidas += 1

        totalPetsAtent += totalPeticionesAtendidas

        #Limpiamos las colas de recepción para el siguiente ciclo
        colaRecepcionA = []
        colaRecepcionB = []
        colaRecepcionC = []

    #─── 3. ANIMACIÓN DE CÍRCULOS EN TRÁNSITO ─────────
    #En cada frame movemos todos los círculos hacia su núcleo destino
    #Iteramos sobre una copia [:] para poder eliminar elementos durante el bucle
    for p in peticiones_en_transito[:]:

        #Calculamos el vector de dirección hacia el destino
        dx   = p["target_x"] - p["x"]
        dy   = p["target_y"] - p["y"]

        #Calculamos la distancia euclidiana al destino
        dist = (dx**2 + dy**2) ** 0.5

        #Velocidad de desplazamiento del círculo en píxeles por frame
        velocidad_anim = 25

        if dist > velocidad_anim:
            #Si el círculo no ha llegado — lo movemos en la dirección del destino
            #Normalizamos el vector (dx/dist, dy/dist) y multiplicamos por velocidad
            p["x"] += (dx / dist) * velocidad_anim
            p["y"] += (dy / dist) * velocidad_anim
        else:
            #Si el círculo llegó a su destino — lo eliminamos de la lista
            #remove() elimina la primera ocurrencia del elemento en la lista
            peticiones_en_transito.remove(p)

    #─── 4. CÁLCULO DE CARGA TOTAL ACTUAL ─────────────
    #Calculamos Q total sumando todos los núcleos en este frame
    #Este valor se muestra en el dashboard inferior
    cargaTotalPeticiones = 0
    for nucleo in nucleos:
        cargaTotalPeticiones += len(nucleo["ALTA"])
        cargaTotalPeticiones += len(nucleo["MEDIA"])
        cargaTotalPeticiones += len(nucleo["BAJA"])

    #Actualizamos el pico máximo si la carga actual lo supera
    if cargaTotalPeticiones > max_carga_registrada:
        max_carga_registrada = cargaTotalPeticiones

    #─── 5. RENDERIZADO ───────────────────────────────
    #Cada frame borramos la pantalla y redibujamos todo desde cero
    #fill() rellena toda la pantalla con el color de fondo
    pantalla.fill(FONDO)

    #Determinamos el color de estado según la carga actual
    #Verde: operación normal / Amarillo: cerca del equilibrio / Rojo: saturación
    color_estado  = VERDE_OK
    alerta_activa = False

    if cargaTotalPeticiones >= C:
        #Carga igual o mayor a la capacidad máxima — estado crítico
        color_estado  = ROJO_CRITIC
        alerta_activa = True
    elif cargaTotalPeticiones >= EQUILIBRIO:
        #Carga igual o mayor al punto de equilibrio — advertencia
        color_estado  = AMARILLO_WARN
        alerta_activa = True

    #El borde de los núcleos parpadea cuando hay alerta
    #frame_count % 20 < 10: verdadero la mitad del tiempo → efecto de parpadeo
    mostrar_alerta = alerta_activa and (frame_count % 20 < 10)

    #Dibujamos los 4 núcleos del procesador BCM2711
    #enumerate() nos da el índice i y el diccionario n simultáneamente
    for i, n in enumerate(nucleos):

        #Leemos la cantidad de peticiones en cada sublista del núcleo actual
        c_alta       = len(n["ALTA"])
        c_media      = len(n["MEDIA"])
        c_baja       = len(n["BAJA"])
        carga_nucleo = c_alta + c_media + c_baja

        #El borde del núcleo cambia de color cuando hay alerta activa
        borde_color = color_estado if mostrar_alerta else (80, 80, 90)

        #Creamos el rectángulo del núcleo con sus coordenadas y dimensiones
        rect_n = pygame.Rect(X_NUCLEOS, Y_NUCLEOS[i], NUCLEO_ANCHO, NUCLEO_ALTO)

        #Dibujamos el fondo del rectángulo (relleno oscuro)
        pygame.draw.rect(pantalla, (28, 28, 35), rect_n)

        #Dibujamos el borde del rectángulo (grosor 2 píxeles)
        pygame.draw.rect(pantalla, borde_color, rect_n, 2)

        #Renderizamos el nombre del núcleo como superficie de texto
        #render() devuelve una superficie — blit() la dibuja en pantalla
        txt_n = fuente_media.render(f"NÚCLEO {i+1}", True, BLANCO)
        pantalla.blit(txt_n, (X_NUCLEOS + 12, Y_NUCLEOS[i] + 8))

        #Mostramos el conteo de peticiones por prioridad dentro del núcleo
        txt_alta = fuente_peque.render(f"Alta (Rojo): {c_alta}", True, COLOR_ALTA)
        txt_med  = fuente_peque.render(f"Media (Amar): {c_media}", True, COLOR_MEDIA)
        txt_baja = fuente_peque.render(f"Baja (Azul): {c_baja}", True, COLOR_BAJA)

        pantalla.blit(txt_alta, (X_NUCLEOS + 12, Y_NUCLEOS[i] + 32))
        pantalla.blit(txt_med,  (X_NUCLEOS + 12, Y_NUCLEOS[i] + 50))
        pantalla.blit(txt_baja, (X_NUCLEOS + 12, Y_NUCLEOS[i] + 68))

        #Mostramos la carga total del núcleo
        #El color cambia según si la carga es alta o no
        color_total = VERDE_OK if carga_nucleo < 15 else AMARILLO_WARN
        txt_tot = fuente_media.render(f"Total: {carga_nucleo}", True, color_total)
        pantalla.blit(txt_tot, (X_NUCLEOS + 115, Y_NUCLEOS[i] + 8))

    #Dibujamos los círculos de peticiones en tránsito
    for p in peticiones_en_transito:

        #Elegimos el color del círculo según la prioridad de la petición
        if p["prioridad"] == "ALTA":
            color_prio = COLOR_ALTA
        elif p["prioridad"] == "MEDIA":
            color_prio = COLOR_MEDIA
        else:
            color_prio = COLOR_BAJA

        #Dibujamos el círculo con radio 16 píxeles en la posición actual
        pygame.draw.circle(pantalla, color_prio,
                           (int(p["x"]), int(p["y"])), 16)

        #Dibujamos la etiqueta del tipo de petición dentro del círculo
        txt_p = fuente_peque.render(f"pet{p['tipo']}", True, (20, 20, 20))
        pantalla.blit(txt_p, (int(p["x"]) - 14, int(p["y"]) - 6))

    #─── 6. DASHBOARD INFERIOR ────────────────────────
    #Línea separadora horizontal entre la zona de núcleos y el dashboard
    pygame.draw.line(pantalla, (65, 65, 75), (0, 540), (ANCHO, 540), 2)

    #Mensaje de estado dinámico según la carga actual
    if cargaTotalPeticiones >= C:
        #Estado crítico — servidor saturado
        msg = f"ALERTA CRÍTICA: CAPACIDAD COMPLETA ({cargaTotalPeticiones} / {C})"
        txt_status = fuente_grande.render(msg, True, ROJO_CRITIC)
    elif cargaTotalPeticiones >= EQUILIBRIO:
        #Advertencia — carga supera el punto de equilibrio
        msg = f"ADVERTENCIA: SOBREPASANDO EL EQUILIBRIO ({cargaTotalPeticiones} > {EQUILIBRIO})"
        txt_status = fuente_grande.render(msg, True, AMARILLO_WARN)
    else:
        #Estado normal — operación estable
        txt_status = fuente_grande.render(
            "ESTADO GENERAL DEL PROCESADOR: ESTABLE", True, VERDE_OK)

    pantalla.blit(txt_status, (30, 555))

    #Panel informativo con métricas del ciclo actual
    txt_info = fuente_media.render(
        f"Tiempo Simulado: {ciclo_actual * H}s  |  "
        f"Carga Pendiente Total (Q): {cargaTotalPeticiones}  |  "
        f"Pico Máximo Alcanzado: {max_carga_registrada}",
        True, BLANCO)
    pantalla.blit(txt_info, (30, 595))

    #Panel con métricas históricas acumuladas de toda la simulación
    txt_historico = fuente_peque.render(
        f"Historial Acumulado -> "
        f"Válidas A: {totalPetsValidasA} | B: {totalPetsValidasB} | C: {totalPetsValidasC}  ||  "
        f"Despachadas Totales: {totalPetsAtent}",
        True, GRIS_TEXTO)
    pantalla.blit(txt_historico, (30, 622))

    #Actualizamos la pantalla — muestra el frame completamente dibujado
    #Sin esta línea la pantalla no se actualiza visualmente
    pygame.display.flip()

    #Limitamos la velocidad a 60 FPS para no consumir CPU innecesariamente
    #tick(60) espera el tiempo necesario para mantener 60 frames por segundo
    reloj.tick(60)

#═══════════════════════════════════════════════════════
#CIERRE LIMPIO DE PYGAME
#Se ejecuta cuando el usuario cierra la ventana
#═══════════════════════════════════════════════════════

#Liberamos todos los recursos de pygame
pygame.quit()

#Terminamos el programa de Python completamente
sys.exit()