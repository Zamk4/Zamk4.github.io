import os
import sys
import random
import warnings

# --- CONFIGURACIÓN DE RESPALDO GRÁFICO (MESA LINUX) ---
os.environ['mesa_glthread'] = 'false'
os.environ['__GLX_VENDOR_LIBRARY_NAME'] = 'mesa'
os.environ['SDL_RENDER_DRIVER'] = 'software'

warnings.filterwarnings("ignore", category=RuntimeWarning)
import pygame

# Inicialización de componentes
pygame.init()
pygame.font.init()

# Dimensiones de la pantalla
ANCHO = 1100
ALTO = 650
pantalla = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption('Simulador de Carga Fiel - Raspberry Pi 4 (BCM2711)')

# Reloj y Fuentes
reloj = pygame.time.Clock()
fuente_peque = pygame.font.SysFont('Arial', 12)
fuente_media = pygame.font.SysFont('Arial', 15, bold=True)
fuente_grande = pygame.font.SysFont('Arial', 22, bold=True)

# --- CONSTANTES MATEMÁTICAS DE TU SIMULACIÓN ---
LAMBDA_A = 0.5
LAMBDA_B = 0.3
LAMBDA_C = 0.2
MU = 0.2
C = 60         # Capacidad Máxima
EQUILIBRIO = 45 # Punto de advertencia
H = 1          # Paso de tiempo original

# --- CONFIGURACIÓN GEOMÉTRICA DE NÚCLEOS ---
NUCLEO_ANCHO = 190
NUCLEO_ALTO = 95
X_NUCLEOS = 820
Y_NUCLEOS = [60, 180, 300, 420]

# Estructura lógica original de tus núcleos
nucleos = [
    {"ALTA": [], "MEDIA": [], "BAJA": []},
    {"ALTA": [], "MEDIA": [], "BAJA": []},
    {"ALTA": [], "MEDIA": [], "BAJA": []},
    {"ALTA": [], "MEDIA": [], "BAJA": []}
]

# Lista para almacenar las peticiones visuales en movimiento
peticiones_en_transito = []

# Contadores globales acumulativos (Métricas de tu script)
totalPetsValidasA = 0
totalPetsValidasB = 0
totalPetsValidasC = 0
totalPetsAtent = 0
ciclo_actual = 0
max_carga_registrada = 0

# Colores estéticos (Paleta Dark/Modern)
FONDO = (18, 18, 23)
GRIS_TEXTO = (170, 170, 180)
BLANCO = (255, 255, 255)
VERDE_OK = (46, 204, 113)
AMARILLO_WARN = (241, 196, 15)
ROJO_CRITIC = (231, 76, 60)

# Colores por Prioridad
COLOR_ALTA = (231, 76, 60)   # Rojo
COLOR_MEDIA = (241, 196, 15) # Amarillo
COLOR_BAJA = (52, 152, 219)  # Azul

frame_count = 0
ejecutando = True

# Para acelerar un poco la visualización del tiempo y llegar rápido al ciclo 100+,
# reducimos los fotogramas requeridos por ciclo a 15 (4 ciclos por segundo real).
FRAMES_POR_CICLO = 15 

while ejecutando:
    frame_count += 1
    
    # --- 1. CAPTURA DE EVENTOS ---
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            ejecutando = False

    # --- 2. LÓGICA MATEMÁTICA COPIADA DE TU SCRIPT ---
    if frame_count % FRAMES_POR_CICLO == 0:
        ciclo_actual += 1
        
        # Llegada de peticiones
        cantidadPeticioneXRevisar1 = random.randint(0, 16)
        cantidadPeticioneXRevisar2 = random.randint(0, 16)
        cantidadPeticioneXRevisar3 = random.randint(0, 16)
        
        colaRecepcionA = [{"tipo": "A", "U": None, "prioridad": None} for _ in range(cantidadPeticioneXRevisar1)]
        colaRecepcionB = [{"tipo": "B", "U": None, "prioridad": None} for _ in range(cantidadPeticioneXRevisar2)]
        colaRecepcionC = [{"tipo": "C", "U": None, "prioridad": None} for _ in range(cantidadPeticioneXRevisar3)]
        
        # Validación de peticiones tipo A
        peticionesValidasA = []
        for peticionXRevisarA in colaRecepcionA:
            U = random.uniform(0.0, 1.0)
            peticionXRevisarA["U"] = U
            if U <= LAMBDA_A:
                peticionesValidasA.append(peticionXRevisarA)

        # Validación de peticiones tipo B
        peticionesValidasB = []
        for peticionXRevisarB in colaRecepcionB:
            U = random.uniform(0.0, 1.0)
            peticionXRevisarB["U"] = U
            if U <= LAMBDA_B:
                peticionesValidasB.append(peticionXRevisarB)

        # Validación de peticiones tipo C
        peticionesValidasC = []
        for peticionXRevisarC in colaRecepcionC:
            U = random.uniform(0.0, 1.0)
            peticionXRevisarC["U"] = U
            if U <= LAMBDA_C:
                peticionesValidasC.append(peticionXRevisarC)

        validas_A = len(peticionesValidasA)
        validas_B = len(peticionesValidasB)
        validas_C = len(peticionesValidasC)

        totalPetsValidasA += validas_A
        totalPetsValidasB += validas_B
        totalPetsValidasC += validas_C
        
        totalPeticionesValidas = peticionesValidasA + peticionesValidasB + peticionesValidasC

        # Asignación de Prioridades
        for peticionXPriorizar in totalPeticionesValidas:
            U = peticionXPriorizar["U"]
            if 0.0 <= U <= 0.15:
                peticionXPriorizar["prioridad"] = "ALTA"
            elif 0.16 <= U <= 0.39:
                peticionXPriorizar["prioridad"] = "MEDIA"
            else:
                peticionXPriorizar["prioridad"] = "BAJA"
        
        prioridadAlta = [cp for cp in totalPeticionesValidas if cp["prioridad"] == "ALTA"]
        prioridadMedia = [cp for cp in totalPeticionesValidas if cp["prioridad"] == "MEDIA"]
        prioridadBaja = [cp for cp in totalPeticionesValidas if cp["prioridad"] == "BAJA"]

        peticionesOrdenadasXPrioridad = prioridadAlta + prioridadMedia + prioridadBaja

        # Ciclo de asignación al núcleo con menor carga (Balanceador)
        for contPetsXAsignar in peticionesOrdenadasXPrioridad:
            totalPetsNucleo1 = len(nucleos[0]["ALTA"]) + len(nucleos[0]["MEDIA"]) + len(nucleos[0]["BAJA"])
            totalPetsNucleo2 = len(nucleos[1]["ALTA"]) + len(nucleos[1]["MEDIA"]) + len(nucleos[1]["BAJA"])
            totalPetsNucleo3 = len(nucleos[2]["ALTA"]) + len(nucleos[2]["MEDIA"]) + len(nucleos[2]["BAJA"])
            totalPetsNucleo4 = len(nucleos[3]["ALTA"]) + len(nucleos[3]["MEDIA"]) + len(nucleos[3]["BAJA"])

            totalCargaXNucleo = [totalPetsNucleo1, totalPetsNucleo2, totalPetsNucleo3, totalPetsNucleo4]

            minimo = totalCargaXNucleo[0]
            indice_minimo = 0
            for nucleoXVerificar in range(1, 4):
                if totalCargaXNucleo[nucleoXVerificar] < minimo:
                    minimo = totalCargaXNucleo[nucleoXVerificar]
                    indice_minimo = nucleoXVerificar

            prioridad = contPetsXAsignar["prioridad"]
            
            # ATENCIÓN: Para que los números cuadren exactos con tus iteraciones matemáticas,
            # la petición entra directo al núcleo lógico, y lanzamos la bolita como efecto visual de llegada.
            nucleos[indice_minimo][prioridad].append(contPetsXAsignar)
            
            peticiones_en_transito.append({
                "x": 30,
                "y": random.randint(60, ALTO - 180),
                "target_x": X_NUCLEOS,
                "target_y": Y_NUCLEOS[indice_minimo] + (NUCLEO_ALTO // 2),
                "tipo": contPetsXAsignar["tipo"],
                "prioridad": prioridad
            })
            
        # --- TU CÓDIGO EXACTO DE ATENCIÓN / DESPACHO DE PETICIONES ---
        totalPeticionesAtendidas = 0  # <--- Tu variable global clave afuera del bucle

        for nucleo in nucleos:
            totalPetsEnNucleo = len(nucleo["ALTA"]) + len(nucleo["MEDIA"]) + len(nucleo["BAJA"])
            despachos = int(MU * totalPetsEnNucleo * H)
            
            if totalPetsEnNucleo > 0 and despachos == 0:
                despachos = 1

            while despachos > 0 and len(nucleo["ALTA"]) > 0:
                nucleo["ALTA"].pop(0)
                despachos -= 1
                totalPeticionesAtendidas += 1

            while despachos > 0 and len(nucleo["MEDIA"]) > 0:
                nucleo["MEDIA"].pop(0)
                despachos -= 1
                totalPeticionesAtendidas += 1

            while despachos > 0 and len(nucleo["BAJA"]) > 0:
                nucleo["BAJA"].pop(0)
                despachos -= 1
                totalPeticionesAtendidas += 1
                
        totalPetsAtent += totalPeticionesAtendidas

        # Limpieza de colas temporales para el ciclo
        colaRecepcionA = []
        colaRecepcionB = []
        colaRecepcionC = []

    # --- 3. ANIMACIÓN DE LAS ESFERAS EN TRÁNSITO ---
    for p in peticiones_en_transito[:]:
        dx = p["target_x"] - p["x"]
        dy = p["target_y"] - p["y"]
        dist = (dx**2 + dy**2)**0.5
        
        velocidad_anim = 25
        if dist > velocidad_anim:
            p["x"] += (dx / dist) * velocidad_anim
            p["y"] += (dy / dist) * velocidad_anim
        else:
            peticiones_en_transito.remove(p)

    # --- 4. CALCULO DE CARGA TOTAL DEL CICLO ACTUAL ---
    cargaTotalPeticiones = 0
    for nucleo in nucleos:
        cargaTotalPeticiones += len(nucleo["ALTA"])
        cargaTotalPeticiones += len(nucleo["MEDIA"])
        cargaTotalPeticiones += len(nucleo["BAJA"])
        
    if cargaTotalPeticiones > max_carga_registrada:
        max_carga_registrada = cargaTotalPeticiones

    # --- 5. RENDERIZADO / DIBUJO ---
    pantalla.fill(FONDO)
    
    # Manejo de colores de advertencias según tus especificaciones
    color_estado = VERDE_OK
    alerta_activa = False
    
    if cargaTotalPeticiones >= C:
        color_estado = ROJO_CRITIC
        alerta_activa = True
    elif cargaTotalPeticiones >= EQUILIBRIO:
        color_estado = AMARILLO_WARN
        alerta_activa = True
        
    mostrar_alerta = alerta_activa and (frame_count % 20 < 10)

    # DIBUJO DE LOS NÚCLEOS DE PROCESAMIENTO
    for i, n in enumerate(nucleos):
        c_alta = len(n["ALTA"])
        c_media = len(n["MEDIA"])
        c_baja = len(n["BAJA"])
        carga_nucleo = c_alta + c_media + c_baja
        
        borde_color = color_estado if mostrar_alerta else (80, 80, 90)
            
        rect_n = pygame.Rect(X_NUCLEOS, Y_NUCLEOS[i], NUCLEO_ANCHO, NUCLEO_ALTO)
        pygame.draw.rect(pantalla, (28, 28, 35), rect_n)
        pygame.draw.rect(pantalla, borde_color, rect_n, 2)
        
        # Nombres de los núcleos
        txt_n = fuente_media.render(f"NÚCLEO {i+1}", True, BLANCO)
        pantalla.blit(txt_n, (X_NUCLEOS + 12, Y_NUCLEOS[i] + 8))
        
        # Conteo individual interno por prioridades
        txt_alta = fuente_peque.render(f"Alta (Rojo): {c_alta}", True, COLOR_ALTA)
        txt_med = fuente_peque.render(f"Media (Amar): {c_media}", True, COLOR_MEDIA)
        txt_baja = fuente_peque.render(f"Baja (Azul): {c_baja}", True, COLOR_BAJA)
        
        pantalla.blit(txt_alta, (X_NUCLEOS + 12, Y_NUCLEOS[i] + 32))
        pantalla.blit(txt_med, (X_NUCLEOS + 12, Y_NUCLEOS[i] + 50))
        pantalla.blit(txt_baja, (X_NUCLEOS + 12, Y_NUCLEOS[i] + 68))
        
        # Carga parcial de este núcleo
        txt_tot = fuente_media.render(f"Total: {carga_nucleo}", True, VERDE_OK if carga_nucleo < 15 else AMARILLO_WARN)
        pantalla.blit(txt_tot, (X_NUCLEOS + 115, Y_NUCLEOS[i] + 8))

    # DIBUJO DE LAS PETICIONES VIAJERAS
    for p in peticiones_en_transito:
        color_prio = COLOR_ALTA if p["prioridad"] == "ALTA" else (COLOR_MEDIA if p["prioridad"] == "MEDIA" else COLOR_BAJA)
        pygame.draw.circle(pantalla, color_prio, (int(p["x"]), int(p["y"])), 16)
        
        txt_p = fuente_peque.render(f"pet{p['tipo']}", True, (20, 20, 20))
        pantalla.blit(txt_p, (int(p["x"]) - 14, int(p["y"]) - 6))

    # --- 6. CUADRO DE MÁNDOS INFERIOR (DASHBOARD) ---
    pygame.draw.line(pantalla, (65, 65, 75), (0, 540), (ANCHO, 540), 2)
    
    # Textos Dinámicos de Estado de Carga
    if cargaTotalPeticiones >= C:
        txt_status = fuente_grande.render(f"ALERTA CRÍTICA: CAPACIDAD COMPLETA ({cargaTotalPeticiones} / {C})", True, ROJO_CRITIC)
    elif cargaTotalPeticiones >= EQUILIBRIO:
        txt_status = fuente_grande.render(f"ADVERTENCIA: SOBREPASANDO EL EQUILIBRIO ({cargaTotalPeticiones} > {EQUILIBRIO})", True, AMARILLO_WARN)
    else:
        txt_status = fuente_grande.render("ESTADO GENERAL DEL PROCESADOR: ESTABLE", True, VERDE_OK)
        
    pantalla.blit(txt_status, (30, 555))
    
    # Panel Informativo de Simulación General
    txt_info = fuente_media.render(
        f"Tiempo Simulado: {ciclo_actual * H}s  |  Carga Pendiente Total (Q): {cargaTotalPeticiones}  |  Pico Máximo Alcanzado: {max_carga_registrada}", 
        True, BLANCO
    )
    pantalla.blit(txt_info, (30, 595))
    
    # Métricas Históricas Acumuladas
    txt_historico = fuente_peque.render(
        f"Historial Acumulado -> Válidas A: {totalPetsValidasA} | B: {totalPetsValidasB} | C: {totalPetsValidasC}  ||  Despachadas Totales: {totalPetsAtent}",
        True, GRIS_TEXTO
    )
    pantalla.blit(txt_historico, (30, 622))

    pygame.display.flip()
    reloj.tick(60)

pygame.quit()
sys.exit()