import os
import sys
import random
import warnings

# --- CONFIGURACIÓN DE RESPALDO GRÁFICO (MESA LINUX) ---
os.environ['mesa_glthread'] = 'false'
os.environ['__GLX_VENDOR_LIBRARY_NAME'] = 'mesa'
os.environ['SDL_RENDER_DRIVER'] = 'software'

warnings.filterwarnings("ignore", category=RuntimeWarning)
import pygame

# Inicialización de componentes
pygame.init()
pygame.font.init()

# Dimensiones de la pantalla
ANCHO = 1000
ALTO = 650
pantalla = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption('Simulador de Carga - Raspberry Pi 4 (BCM2711)')

# Reloj y Fuentes
reloj = pygame.time.Clock()
fuente_peque = pygame.font.SysFont('Arial', 12)
fuente_media = pygame.font.SysFont('Arial', 16, bold=True)
fuente_grande = pygame.font.SysFont('Arial', 22, bold=True)

# --- CONSTANTES MATEMÁTICAS DE TU SIMULACIÓN ---
LAMBDA_A = 0.5
LAMBDA_B = 0.3
LAMBDA_C = 0.2
MU = 0.2
C = 60         # Capacidad Máxima
EQUILIBRIO = 45 # Punto de advertencia

# --- CONFIGURACIÓN DE NÚCLEOS ---
# Posiciones fijas para los rectángulos de los 4 núcleos
NUCLEO_ANCHO = 160
NUCLEO_ALTO = 90
X_NUCLEOS = 750
Y_NUCLEOS = [80, 200, 320, 440]

# Estructura lógica original de tus núcleos
nucleos = [
    {"ALTA": [], "MEDIA": [], "BAJA": []},
    {"ALTA": [], "MEDIA": [], "BAJA": []},
    {"ALTA": [], "MEDIA": [], "BAJA": []},
    {"ALTA": [], "MEDIA": [], "BAJA": []}
]

# Lista para almacenar las peticiones visuales en movimiento
peticiones_en_transito = []

# Contadores globales acumulativos (Tus métricas)
total_validas_A = 0
total_validas_B = 0
total_validas_C = 0
total_atendidas = 0
ciclo_actual = 0
max_carga_registrada = 0

# Colores estéticos (Paleta Dark/Modern)
FONDO = (20, 20, 25)
GRIS_TEXTO = (180, 180, 180)
BLANCO = (255, 255, 255)
VERDE_OK = (46, 204, 113)
AMARILLO_WARN = (241, 196, 15)
ROJO_CRITIC = (231, 76, 60)

# Colores por Prioridad
COLOR_ALTA = (231, 76, 60)   # Rojo
COLOR_MEDIA = (241, 196, 15) # Amarillo/Naranja
COLOR_BAJA = (52, 152, 219)  # Azul

# Marco de animación (Contador de ciclos para parpadeo)
frame_count = 0

ejecutando = True

while ejecutando:
    frame_count += 1
    
    # --- 1. CAPTURA DE EVENTOS ---
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            ejecutando = False

    # --- 2. LÓGICA MATEMÁTICA POR CICLO (Cada segundo de simulación) ---
    # Para que la animación sea fluida, ejecutamos un paso matemático cada 30 fotogramas de Pygame
    if frame_count % 30 == 0:
        ciclo_actual += 1
        
        # Generación aleatoria de cargas entrantes
        cant_A = random.randint(0, 4)
        cant_B = random.randint(0, 4)
        cant_C = random.randint(0, 4)
        
        cola_A = [{"tipo": "A", "U": None, "prioridad": None} for _ in range(cant_A)]
        cola_B = [{"tipo": "B", "U": None, "prioridad": None} for _ in range(cant_B)]
        cola_C = [{"tipo": "C", "U": None, "prioridad": None} for _ in range(cant_C)]
        
        # Filtrado por probabilidad (Tus condicionales exactos)
        validas = []
        for p in cola_A:
            p["U"] = random.uniform(0.0, 1.0)
            if p["U"] <= LAMBDA_A: 
                validas.append(p); total_validas_A += 1
        for p in cola_B:
            p["U"] = random.uniform(0.0, 1.0)
            if p["U"] <= LAMBDA_B: 
                validas.append(p); total_validas_B += 1
        for p in cola_C:
            p["U"] = random.uniform(0.0, 1.0)
            if p["U"] <= LAMBDA_C: 
                validas.append(p); total_validas_C += 1
                
        # Clasificación por Prioridad según el valor aleatorio U
        for p in validas:
            u = p["U"]
            if 0.0 <= u <= 0.15:
                p["prioridad"] = "ALTA"
            elif 0.16 <= u <= 0.39:
                p["prioridad"] = "MEDIA"
            else:
                p["prioridad"] = "BAJA"
                
        # Ordenamiento estable por prioridades
        ordenadas = ([p for p in validas if p["prioridad"] == "ALTA"] + 
                     [p for p in validas if p["prioridad"] == "MEDIA"] + 
                     [p for p in validas if p["prioridad"] == "BAJA"])
        
        # Balanceo de carga dinámico hacia el núcleo más vacío
        for p in ordenadas:
            cargas = [len(n["ALTA"]) + len(n["MEDIA"]) + len(n["BAJA"]) for n in nucleos]
            indice_minimo = cargas.index(min(cargas))
            
            # Almacenamos la petición en la estructura matemática
            nucleos[indice_minimo][p["prioridad"]].append(p)
            
            # Creamos un objeto visual para la animación del viaje
            peticiones_en_transito.append({
                "x": 50,
                "y": random.randint(50, ALTO - 200),
                "target_x": X_NUCLEOS,
                "target_y": Y_NUCLEOS[indice_minimo] + (NUCLEO_ALTO // 2),
                "tipo": p["tipo"],
                "prioridad": p["prioridad"]
            })
            
        # Despacho / Atención de tareas en los núcleos
        for n in nucleos:
            tot = len(n["ALTA"]) + len(n["MEDIA"]) + len(n["BAJA"])
            despachos = int(MU * tot * 1)
            if tot > 0 and despachos == 0: 
                despachos = 1
                
            atendidas_nucleo = 0
            for prio in ["ALTA", "MEDIA", "BAJA"]:
                while atendidas_nucleo < despachos and len(n[prio]) > 0:
                    n[prio].pop(0)
                    atendidas_nucleo += 1
                    total_atendidas += 1

    # --- 3. ACTUALIZACIÓN DE POSICIONES INTERNAS DE LA ANIMACIÓN ---
    # Movemos los círculos que viajan hacia los rectángulos de destino
    for p in peticiones_en_transito[:]:
        dx = p["target_x"] - p["x"]
        dy = p["target_y"] - p["y"]
        dist = (dx**2 + dy**2)**0.5
        
        velocidad_anim = 12
        if dist > velocidad_anim:
            p["x"] += (dx / dist) * velocidad_anim
            p["y"] += (dy / dist) * velocidad_anim
        else:
            # Al llegar a su destino, el círculo se elimina de la lista de tránsito
            peticiones_en_transito.remove(p)

    # --- 4. CÁLCULO DE MÉTRICAS GLOBALES DE CARGA ---
    carga_actual_total = sum(len(n["ALTA"]) + len(n["MEDIA"]) + len(n["BAJA"]) for n in nucleos)
    if carga_actual_total > max_carga_registrada:
        max_carga_registrada = carga_actual_total

    # --- 5. RENDERIZADO / DIBUJO ---
    pantalla.fill(FONDO)
    
    # Determinamos el estado del sistema para alertas de color y parpadeos
    color_estado = VERDE_OK
    alerta_activa = False
    
    if carga_actual_total >= C:
        color_estado = ROJO_CRITIC
        alerta_activa = True
    elif carga_actual_total >= EQUILIBRIO:
        color_estado = AMARILLO_WARN
        alerta_activa = True
        
    # Efecto parpadeo: Si la alerta está activa, alternamos visibilidad cada 15 fotogramas
    mostrar_alerta = alerta_activa and (frame_count % 30 < 15)

    # DIBUJO DE LOS NÚCLEOS (Rectángulos de Procesamiento)
    for i, n in enumerate(nucleos):
        cant_prio_alta = len(n["ALTA"])
        cant_prio_med = len(n["MEDIA"])
        cant_prio_baja = len(n["BAJA"])
        carga_nucleo = cant_prio_alta + cant_prio_med + cant_prio_baja
        
        # Color del borde del núcleo condicionado al estado crítico general
        borde_color = color_estado if mostrar_alerta else (100, 100, 110)
        
        # Rectángulo principal del núcleo
        rect_n = pygame.Rect(X_NUCLEOS, Y_NUCLEOS[i], NUCLEO_ANCHO, NUCLEO_ALTO)
        pygame.draw.rect(pantalla, (35, 35, 45), rect_n)
        pygame.draw.rect(pantalla, borde_color, rect_n, 2)
        
        # Etiquetas de identificación de los núcleos
        txt_n = fuente_media.render(f"NÚCLEO {i+1}", True, BLANCO)
        pantalla.blit(txt_n, (X_NUCLEOS + 10, Y_NUCLEOS[i] + 8))
        
        # Desglose de prioridades dentro de cada caja de núcleo
        txt_detalles = fuente_peque.render(
            f"Alta (R): {cant_prio_alta} | Med (N): {cant_prio_med} | Baja (A): {cant_prio_baja}", 
            True, GRIS_TEXTO
        )
        pantalla.blit(txt_detalles, (X_NUCLEOS + 10, Y_NUCLEOS[i] + 38))
        
        # Contador total de peticiones acumuladas en el núcleo
        txt_tot = fuente_media.render(f"Total: {carga_nucleo}", True, VERDE_OK if carga_nucleo < EQUILIBRIO//4 else AMARILLO_WARN)
        pantalla.blit(txt_tot, (X_NUCLEOS + 10, Y_NUCLEOS[i] + 62))

    # DIBUJO DE LAS PETICIONES EN TRÁNSITO (Círculos Dinámicos)
    for p in peticiones_en_transito:
        color_prio = COLOR_ALTA if p["prioridad"] == "ALTA" else (COLOR_MEDIA if p["prioridad"] == "MEDIA" else COLOR_BAJA)
        
        # Dibujamos el círculo contenedor de la petición
        pygame.draw.circle(pantalla, color_prio, (int(p["x"]), int(p["y"])), 16)
        
        # Texto identificador incrustado dentro de la figura viajera (peticionA, peticionB, etc.)
        txt_p = fuente_peque.render(f"pet{p['tipo']}", True, (20, 20, 20))
        pantalla.blit(txt_p, (int(p["x"]) - 12, int(p["y"]) - 6))

    # --- 6. PANEL DE CONTROL / DASHBOARD DE MÉTRICAS (ZONA INFERIOR) ---
    pygame.draw.line(pantalla, (60, 60, 70), (0, 550), (ANCHO, 550), 2)
    
    # Texto de estado del sistema y Alertas visuales críticas
    if carga_actual_total >= C:
        txt_status = fuente_grande.render("ALERTA: CAPACIDAD COMPLETA SATURED!", True, ROJO_CRITIC)
    elif carga_actual_total >= EQUILIBRIO:
        txt_status = fuente_grande.render("ADVERTENCIA: SOBREPASANDO EL EQUILIBRIO", True, AMARILLO_WARN)
    else:
        txt_status = fuente_grande.render("ESTADO: SISTEMA ESTABLE Y BALANCEADO", True, VERDE_OK)
        
    pantalla.blit(txt_status, (30, 565))
    
    # Impresión en pantalla del monitoreo numérico en tiempo real
    txt_info = fuente_media.render(
        f"Ciclo: {ciclo_actual} | Carga Actual Total: {carga_actual_total} / {C} | Max Registrada: {max_carga_registrada}", 
        True, BLANCO
    )
    pantalla.blit(txt_info, (30, 600))
    
    # Resumen histórico acumulado en una columna lateral
    txt_historico = fuente_peque.render(
        f"Histórico Válidas -> A: {total_validas_A} | B: {total_validas_B} | C: {total_validas_C} | Despachadas: {total_atendidas}",
        True, GRIS_TEXTO
    )
    pantalla.blit(txt_historico, (520, 603))

    # Volcado de buffer y actualización física del display a 60 FPS estables
    pygame.display.flip()
    reloj.tick(60)

pygame.quit()
sys.exit()