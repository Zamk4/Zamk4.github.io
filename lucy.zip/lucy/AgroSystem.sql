SELECT * FROM TipoPuesto

SELECT * FROM TipoTurno