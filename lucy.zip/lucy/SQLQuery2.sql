
--1.- Listar el nombre compreto de los empleados, ordenado alfabeticamente por apellido
SELECT Employees.FirstName, Employees.LastName 
FROM Employees
ORDER BY Employees.FirstName

--2.- Listar el id y nombre de los empleados que sean de la ciudad de Seattle

SELECT Employees.EmployeeID, Employees.FirstName, Employees.LastName
FROM Employees
WHERE Employees.City = 'Seattle'

--3.- Obtener un listado con la clave, nombre y categoria de los productos que pertenezcan a la categoria 1, 3 y 5

SELECT Products.ProductID, Products.ProductName, Products.CategoryID
FROM Products
WHERE CategoryID IN (1, 3, 5)

--4.- Obtener el n�mero total de empleados

SELECT COUNT(*) As TotalEmpleados
FROM Employees

--5. Obtener cuantos empleados tengo que sean del pais de Reino unido (UK)

SELECT COUNT(*) As TotalEmpleados
FROM Employees
WHERE Employees.Country = 'UK'

--6.- Obtener el promedio de precio de los productos de la categoria 3
SELECT AVG(UnitPrice) AS PrecioPromedio 
FROM Products
WHERE Products.CategoryID IN (3)
--7.- Obtener el precio mas barato de los productos cuya clave se encuentre entre 60 y 69
SELECT MIN(UnitPrice) AS PrecioMinimo
FROM Products
WHERE Products.ProductID >= 60 AND ProductID <= 69
--8.- Obtener el numero mas alto de unidades en stock de los productos que no se encuentran descontinuados
SELECT MAX(UnitsInStock) AS UnidadEnStockMaxima
FROM Products
WHERE Products.Discontinued = 1
--9.- Obtener el total de unidades en stock que tenemos por todos los productos de la categoria 1
SELECT * FROM Products
SELECT COUNT(UnitsInStock) AS TotalUnidadesEnStock
FROM Products
WHERE Products.CategoryID IN (1)
--10.- Obtener el nombre, direccion y ciudad de los clientes de Mexico, francia y alemania
SELECT * FROM Categories
SELECT ContactName, Address, City
FROM Customers
WHERE Customers.Country IN ('Mexico', 'France', 'Germany')
--11.- Obtener el listado que presente nombre y descripcion de las categorias 2, 5, 7 y 8
SELECT CategoryName, Description
FROM Categories
WHERE Categories.CategoryID IN (2, 5, 7, 8)