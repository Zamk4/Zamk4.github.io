import sys
#IMportación para que no aparezcan el warning de que la versión de pygame no fue configurada para usar esa tecnología AVX2 de forma nativa
import warnings

# Ocultamos la advertencia de AVX2 de la terminal
warnings.filterwarnings("ignore", category=RuntimeWarning)

import pygame

pygame.init()
#Definimos el ancho y el alto de la pantalla
ANCHO = 900
ALTO = 600

pantalla = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption('Simulador de carga - RaspBerry Pi 4')

reloj = pygame.time.Clock()
fuente = pygame.font.SysFont('Arial', 16)
#Posiciones de las peticiones
pos_xa1 = 50
pos_ya2 = 250

pos_xb1 = 50
pos_yb2 = 300

pos_xc1 = 50
pos_yc2 = 350

velocidad = 5
#Posiciones de los nucleos
n1_xa1 = 600
n1_ya2 = 250

n2_xb1 = 600
n2_yb2 = 300

n3_xc1 = 600
n3_yc2 = 350

n4_xc1 = 600
n4_yc2 = 400

ejecutando = True
#Ciclo para emular el juego/animación
while ejecutando:
    #Ciclo para capturar los eventos y poder cerrar la ventana con la X
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            ejecutando = False
    
    #Movimiento de los circulos a la derecha
    pos_xa1 += velocidad
    pos_xb1 += velocidad-1
    pos_xc1 += velocidad+2

    #Si el circulo se pasa del ancho, regresa al final
    if pos_xa1 > ANCHO: pos_xa1 = 0
    if pos_xb1 > ANCHO: pos_xb1 = 0
    if pos_xc1 > ANCHO: pos_xc1 = 0

    #Renderizado de imagen con fondo  gris
    pantalla.fill((30, 30, 30))

    pygame.draw.line(pantalla, (255, 165, 0), (600, 0), (600, ALTO), 2)

    #Creacion de las peticiones
    pygame.draw.circle(pantalla, (0, 100, 255), (pos_xa1, pos_ya2), 15)

    pygame.draw.circle(pantalla, (255, 34, 0), (pos_xb1, pos_yb2), 15)

    pygame.draw.circle(pantalla, (12, 194, 64), (pos_xc1, pos_yc2), 15)

    #Nucleos
    pygame.draw.circle(pantalla, (0, 100, 255), (n1_xa1, n1_ya2), 20)
    pygame.draw.circle(pantalla, (255, 34, 0), (n2_xb1, n2_yb2), 20)
    pygame.draw.circle(pantalla, (0, 100, 255), (n3_xc1, n3_yc2), 20)
    pygame.draw.circle(pantalla, (12, 194, 64), (n4_xc1, n4_yc2), 20)

    pygame.display.flip()
    #Regulación a 60 fotogramas por segundo
    reloj.tick(60)

pygame.quit()
sys.exit()