#Importacion de la libreria random para la utilización de números aleatorios
import random
#Importación para la creación de gráficas
import matplotlib.pyplot as plt
#Importación para la creación de gráficas dinámicas
from matplotlib.animation import FuncAnimation
#Proabailidad de cada tipo de petición sea valida
LAMBDA_A = 0.5
LAMBDA_B = 0.3
LAMBDA_C = 0.2
#Tasa de servicio de cada nucleo por ciclo
MU = 0.2
#Capacidad máxima del servidor
C = 60

#PASO DE TIEMPO EN DECIMAS DE SEGUNDO

#Tamaño de paso del tiempo
#H = 0.1
#Tiempo simulado (500 ciclos * 0.1s = 50 seg simulados)
#CICLOS = 2400

#PASO DE TIEMPO EN SEGUNDOS

#Tamaño de paso del tiempo
H = 1
#Tiempo simulado (500 ciclos * 0.1s = 50 seg simulados)
CICLOS = 480

#Creación de las colas de recepción para cada tipo de petición
colaRecepcionA = []
colaRecepcionB = []
colaRecepcionC = []

#Creación de cada nucleo del procesador BCM2711 de la Raspberry Pi 4
#Cada nucleo cuenta con 3 listas internas para clasificar las prioridades de las peticiones

nucleo1 = {"ALTA": [], "MEDIA": [], "BAJA": []}
nucleo2 = {"ALTA": [], "MEDIA": [], "BAJA": []}
nucleo3 = {"ALTA": [], "MEDIA": [], "BAJA": []}
nucleo4 = {"ALTA": [], "MEDIA": [], "BAJA": []}

#Creación de una lista para recorrer los nuclos fácilmente
nucleos = [nucleo1, nucleo2, nucleo3, nucleo4]
#Cargatotal de peticiones por ciclo
cargaTotalXCiclo = []
#Contadores acumulativos de peticiones para contar cuantas peticiones de cada tipo fueron validas al final de la simulación 
totalPetsValidasA = 0
totalPetsValidasB = 0
totalPetsValidasC = 0

totalPetsAtent = 0

#Ciclo principal para todas la simulaciones
for ciclos in range(CICLOS):
    #Llegada de peticiones, una sola decide cuantas peticiones llegan para cada tipo de petición
    #cantidadPeticioneXRevisar1 = random.randint(0, 11)
    #cantidadPeticioneXRevisar2 = random.randint(0, 6)
    #cantidadPeticioneXRevisar3 = random.randint(0, 3)

    #Entra dentro de la capacidad máxima
    cantidadPeticioneXRevisar1 = random.randint(0, 4)
    cantidadPeticioneXRevisar2 = random.randint(0, 4)
    cantidadPeticioneXRevisar3 = random.randint(0, 4)

    #Creamos las peticiones para cata tipo y lo pasamos a su cola correspondiente
    #Cada petición esta clasificada por su tipo, su valor aleatorio y su prioridad

    for contadorPeticiones in range(cantidadPeticioneXRevisar1):
        colaRecepcionA.append({"tipo": "A", "U": None, "prioridad": None})
    
    for contadorPeticiones in range(cantidadPeticioneXRevisar2):
        colaRecepcionB.append({"tipo": "B", "U": None, "prioridad": None})
    
    for contadorPeticiones in range(cantidadPeticioneXRevisar3):
        colaRecepcionC.append({"tipo": "C", "U": None, "prioridad": None})

    #Validación de peticiones de tipo A
    #Creamos la cola para alojar las paeticiones validas
    peticionesValidasA = []
    #Ciclo para contar las peticiones de la cola de recepción A
    for peticionXRevisarA in colaRecepcionA:
        #Generamos un número aleatorio uniforme entre 0.0 a 1.0
        U = random.uniform(0.0, 1.0)
        #Le asignamos este número alpeticionXRevisarA["U"] = Ueatorio a cada petición
        peticionXRevisarA["U"] = U
        #Si el número aleatorio es menor o igual a la probabilidad de aparición que se establecio en el tipo de petición A
        if U <= LAMBDA_A:
            #Lo pasamos como una petición valida y lo agregamos a la lista de peticiones que son validas de tipo A
            peticionesValidasA.append(peticionXRevisarA)

    #Validación de peticiones de tipo B
    #Creamos la cola para alojar las peticiones validas
    peticionesValidasB = []
    #Ciclo para contar las peticiones de la cola de recepción B
    for peticionXRevisarB in colaRecepcionB:
        #Generamos un número aleatorio uniforme entre 0.0 a 1.0
        U = random.uniform(0.0, 1.0)
        #Le asignamos este número aleatorio a cada petición
        peticionXRevisarB["U"] = U
        #Si el número aleatorio es menor o igual a la probabilidad de aparición que se establecio en el tipo de petición B
        if U <= LAMBDA_B:
            #Lo pasamos como una petición valida y lo agregamos a la lista de peticiones que son validas de tipo B
            peticionesValidasB.append(peticionXRevisarB)

    #Validación de peticiones de tipo C
    #Creamos la cola para alojar las paeticiones validas
    peticionesValidasC = []
    #Ciclo para contar las peticiones de la cola de recepción C
    for peticionXRevisarC in colaRecepcionC:
        #Generamos un número aleatorio uniforme entre 0.0 a 1.0
        U = random.uniform(0.0, 1.0)
        #Le asignamos este número aleatorio a cada petición
        peticionXRevisarC["U"] = U
        #Si el número aleatorio es menor o igual a la probabilidad de aparición que se establecio en el tipo de petición C
        if U <= LAMBDA_C:
            #Lo pasamos como una petición valida y lo agregamos a la lista de peticiones que son validas de tipo C
            peticionesValidasC.append(peticionXRevisarC)

    #Contamos el total de peticiones válidas de cada tipo de petición en cada ciclo
    validas_A = len(peticionesValidasA)
    validas_B = len(peticionesValidasB)
    validas_C = len(peticionesValidasC)

    totalPetsValidasA += validas_A
    totalPetsValidasB += validas_B
    totalPetsValidasC += validas_C
    
    #Agrupamos todas la peticiones de todos lo tipos para procesarlas juntas
    totalPeticionesValidas = peticionesValidasA + peticionesValidasB + peticionesValidasC

    #Asignamos prioridad a cada petición segun su U (valor aleatorio)
    #Ciclo para contar todas las peticiones por asignar prioridad
    for peticionXPriorizar in totalPeticionesValidas:
        #Accedemos al valor de cada petición
        U = peticionXPriorizar["U"]
        #Segun su valor, se le asignara su respectiva prioridad
        if 0.0 <= U <= 0.15:
            peticionXPriorizar["prioridad"] = "ALTA"
        elif 0.16 <= U <= 0.39:
            peticionXPriorizar["prioridad"] = "MEDIA"
        else:
            peticionXPriorizar["prioridad"] = "BAJA"
    
    #Creación de tres listas para clasificar cada petición por prioridad
    prioridadAlta = [contPetPrioridad for contPetPrioridad in totalPeticionesValidas if contPetPrioridad["prioridad"] == "ALTA"]

    prioridadMedia = [contPetPrioridad for contPetPrioridad in totalPeticionesValidas if contPetPrioridad["prioridad"] == "MEDIA"]

    prioridadBaja = [contPetPrioridad for contPetPrioridad in totalPeticionesValidas if contPetPrioridad["prioridad"] == "BAJA"]

    #Unimos todas las listas en orden para que las de mayor prioridad se atiendan primero
    peticionesOrdenadasXPrioridad = prioridadAlta + prioridadMedia + prioridadBaja

    #Ciclo para asignar las peticiones a cada nucleo
    for contPetsXAsignar in peticionesOrdenadasXPrioridad:
        #Primero contamos cuántas peticiones tiene cada núcleo actualmente
        #Cada nuclo tambien se clasifican las peticiones por prioridad y se cuentan cada una
        totalPetsNucleo1 = len(nucleos[0]["ALTA"]) + len(nucleos[0]["MEDIA"]) + len(nucleos[0]["BAJA"])

        totalPetsNucleo2 = len(nucleos[1]["ALTA"]) + len(nucleos[1]["MEDIA"]) + len(nucleos[1]["BAJA"])

        totalPetsNucleo3 = len(nucleos[2]["ALTA"]) + len(nucleos[2]["MEDIA"]) + len(nucleos[2]["BAJA"])

        totalPetsNucleo4 = len(nucleos[3]["ALTA"]) + len(nucleos[3]["MEDIA"]) + len(nucleos[3]["BAJA"])

        #GuardamtotalPetsValidasAos la cantidad total de peticiones de cada nucleo en una lista para compararlos
        totalCargaXNucleo = [totalPetsNucleo1, totalPetsNucleo2, totalPetsNucleo3, totalPetsNucleo4]

        #Encontramos cuál núcleo tiene menos peticiones
        #Empezamos con el total de peticiones del nucleo 1 para empezar a comparar
        minimo = totalCargaXNucleo[0]
        #Definimos la posición (nucleo 1) con menos40 petic carga de peticiones por el momento
        indice_minimo = 0
        #Ciclo para verificar que nucleo es que cuenta con menos carga de peticiones
        #Empezamos de la posición 1 al 3 (nucleo 2 al 4)
        for nucleoXVerificar in range(1, 4):
            #Empezamos verificando si la carga de peticiones del nucleo 2 es menor a la del nucleo 1
            if totalCargaXNucleo[nucleoXVerificar] < minimo:
                #Si es asi, actualizamos el valor del tamaño de carga minimo y la la posición (nucleo 1) con menos carga de peticiones
                minimo = totalCargaXNucleo[nucleoXVerificar]
                indice_minimo = nucleoXVerificar

        #Llamamos a la prioridad de la petición que estamos procesando
        prioridad = peticionXPriorizar["prioridad"]#ALTA - MEDIA - BAJA
        #Localizamos en que nucleo y con que sublista interna es a la que se integrara la petición
        #Indicamos el nucleo más vacío - [indice_minimo]
        #Indicamos a que clasidicación se dirijar la petición dentro del nucleo - [prioridad]
        #Finalmente agragamos la petición a esa lista interna de prioridad dentro del nucleo que esta más vacío.
        nucleos[indice_minimo][prioridad].append(peticionXPriorizar)
    
    #Variable para almacenar el total de peticiones despachadas
    totalPeticionesAtendidas = 0

    #Ciclo para atender las peticiones a cada ciclo
    #Recorremos cada nucleo, empezando por el primero (del 0 al 3)
    for nucleo in nucleos:
        #Calculamos cuantas peticiones tiene el primer nucleo
        totalPetsEnNucleo = len(nucleo["ALTA"]) + len(nucleo["MEDIA"]) + len(nucleo["BAJA"])
        #Aplicamos la fórmula para el despacho de peticiones y redondeamos de forma decreciente con el int
        despachos = int(MU * totalPetsEnNucleo * H)
        #Si hay peticiones y despachos es igual a 0
        if totalPetsEnNucleo > 0 and despachos == 0:
            #Atendemos minimo a unas petición
            despachos = 1

        while totalPeticionesAtendidas < despachos and len(nucleo["ALTA"]) > 0:
            #Eliminamos la primera petición de la lista de alta prioridad, con pop(0)
            nucleo["ALTA"].pop(0)
            #Quitamos la petición para que no entre en los demas ciclos
            #despachos -= 1
            #Sumamos a las peticiones atendidas
            totalPeticionesAtendidas += 1

        while totalPeticionesAtendidas < despachos and len(nucleo["MEDIA"]) > 0:
            #Eliminamos la primera petición de la lista de baja prioridad, con pop(0)
            nucleo["MEDIA"].pop(0)
            #despachos -= 1
            totalPeticionesAtendidas += 1

        while totalPeticionesAtendidas < despachos and len(nucleo["BAJA"]) > 0:
            #Eliminamos la primera petición de la lista de baja prioridad, con pop(0)
            nucleo["BAJA"].pop(0)
            #despachos -= 1
            totalPeticionesAtendidas += 1
    #Total de peticiones atendidas al final de la simulación
    totalPetsAtent += totalPeticionesAtendidas


    #Variable para almacenar la carga total de las peticiones
    cargaTotalPeticiones = 0

    #Ciclo para sumar la carga total de las peticiones en cada ciclo
    #Recorremos cada nucleo, empezando por el primero (del 0 al 3)
    for nucleo in nucleos:
        cargaTotalPeticiones += len(nucleo["ALTA"])
        cargaTotalPeticiones += len(nucleo["MEDIA"])
        cargaTotalPeticiones += len(nucleo["BAJA"])
    
    #Guardamos la carga total del ciclo
    cargaTotalXCiclo.append(cargaTotalPeticiones)

    #Imprimimos información cada 25 ciclos
    #ciclo+1 porque ciclo empieza en 0 y queremos mostrar desde 1
    if (ciclos + 1) % 25 == 0:
        tiempo_actual = (ciclos + 1) * H
        print(f"─── Ciclo {ciclos+1} | Tiempo: {tiempo_actual:.1f}s ───────────────")
        print(f"  Peticiones válidas → A: {validas_A} | B: {validas_B} | C: {validas_C}")
        print(f"  Total despachadas  → {totalPeticionesAtendidas} peticiones")
        print(f"  Carga total en sistema → {cargaTotalPeticiones} peticiones")
        print()

    #Limpiamos las colas de recepción para el siguiente ciclo
    colaRecepcionA = []
    colaRecepcionB = []
    colaRecepcionC = []

# ── RESULTADOS FINALES ─────────────────────────────────────────
print("════════════════════════════════════════")
print("RESULTADOS FINALES DE LA SIMULACIÓN")
print("════════════════════════════════════════")
print(f"Ciclos simulados:        {CICLOS}")
print(f"Tiempo total simulado:   {CICLOS * H} segundos")
print(f"Carga al final:        {cargaTotalXCiclo[-1]} peticiones")
print(f"Carga promedio:              {sum(cargaTotalXCiclo) / len(cargaTotalXCiclo):.2f} peticiones")
print(f"Carga máximo:                {max(cargaTotalXCiclo)} peticiones")
print(f"Carga mínimo:                {min(cargaTotalXCiclo)} peticiones")
print(f"Q* teórico (ec. logística): 45 peticiones")
print()
print(f"Total de peticiones válidas en la simulación → A: {totalPetsValidasA} | B: {totalPetsValidasB} | C: {totalPetsValidasC}")
print(f"Total de peticiones despachadas en la simulación  → {totalPetsAtent} peticiones")
print(f"Carga total en sistema → {cargaTotalPeticiones} peticiones")
print("════════════════════════════════════════")






'''

#Gráficas

#Creamos un vector de tiempo para el eje horizontal
#Necesitamos un valor de tiempo para cada ciclo simulado
tiempo = []
#Ciclo para contar los ciclos simulados
for contCiclos in range(CICLOS):
    #Agrega cada segundo al vector del tiempo para el eje horizontal (Crea la lista de tiempos)
    tiempo.append((contCiclos + 1) * H)

#Creamos una ventana nueva para la primera gráfica - con plt.figure
#Definimos el tamaño en pulgadas - con figsize - 10 de ancho y 5 de alto
plt.figure(figsize=(10, 5))

#Dibujamos la linea principal de  la gráfica (con plt.plot) tomado dos listas, tiempo (eje X) y carga total (eje Y) y conecta los puntos en la linea
#Definimos el color
#Definimos el grosor de la línea
#Definimos el texto que aparecera en la leyenda de la gráfica para identificar esta linea
plt.plot(tiempo, cargaTotalXCiclo, color='steelblue', linewidth=2, label='Carga simulada Q(t) - Montecarlo')


#Definimos una linea horizontal (con plt.axhline) en un valor específico del eje Y, con eso la pone exactamente en el equilibrio teórico que
#calculamos en la ecuación logística adaptado a este proyecto
plt.axhline(y=45, color='red', linestyle='--', linewidth=2, label='Q = 45 (equilibrio teórico)')
#Definimos otra linea horizontal para marcar el limite físico del servidor
plt.axhline(y=C, color='orange', linestyle=':', linewidth=2, label=f'Capacidad máxima del C = {C}')

plt.title('Peticiones pendientes por nucleo al final \nRaspberry Pi 4 Model B (BCM2711)')
plt.xlabel('Tiempo (segundos)')
plt.ylabel('Peticiones pendientes')
plt.legend()
#Definimo la cuadricula en el eje Y
plt.grid(True, axis='y')
#Para ajustar el espacio entre los subgráficos
plt.tight_layout()
plt.savefig('grafica_nucleos.png', dpi=150)
plt.show()

'''

#Creación de gráficas dinámicas
tiempo = []
tiempo_animacion = []
carga_animacion = []

fig, ax = plt.subplots(figsize=(10, 5))
peticionesPendientes, = ax.plot([], [], linewidth=2, color='blue', label='Carga simulada Q(t)')


ax.set_title("Carga de servicio de del servidor de la \nRaspberry Pi 4 Model B (BCM2711)")
ax.set_xlabel("Tiempo (segundos)")
ax.set_ylabel("Peticiones pendientes")

#calculamos en la ecuación logística adaptado a este proyecto
plt.axhline(y=45, color='red', linestyle='--', linewidth=2, label='Q = 45 (equilibrio teórico)')
#Definimos otra linea horizontal para marcar el limite físico del servidor
plt.axhline(y=C, color='orange', linestyle=':', linewidth=2, label=f'Capacidad máxima del C = {C}')

plt.grid(True, axis='y')
ax.legend(loc = 'upper right')

tiempo_completo = [(i + 1) * H for i in range(CICLOS)]

def init():
    ax.set_xlim(0, CICLOS * H)
    ax.set_ylim(0, 100)
    peticionesPendientes.set_data([], [])
    return (peticionesPendientes,)

def actualizar(contCiclos):
    nuevo_tiempo = (contCiclos + 1) * H
    tiempo_animacion.append(nuevo_tiempo)
    carga_animacion.append(cargaTotalXCiclo[contCiclos])

    x_data = tiempo_completo[:contCiclos + 1]
    y_data = cargaTotalXCiclo[:contCiclos + 1]

    peticionesPendientes.set_data(x_data, y_data)
    
    if nuevo_tiempo > ax.get_xlim()[1]:
        ax.set_xlim(0, nuevo_tiempo + 10)
    
    fig.canvas.draw_idle()

    return(peticionesPendientes,)



ani = FuncAnimation(fig, actualizar, frames = CICLOS, init_func = init, blit = False, interval = 20, repeat = False)

plt.show()








# Gráfica 2 — Distribución por núcleo al final
plt.figure(figsize=(8, 5))

conteoNucleos   = []
nombresNucleos  = ['Núcleo 1', 'Núcleo 2', 'Núcleo 3', 'Núcleo 4']

for nucleo in nucleos:
    total = len(nucleo["ALTA"]) + len(nucleo["MEDIA"]) + len(nucleo["BAJA"])
    conteoNucleos.append(total)

posiciones = [0, 1, 2, 3]

plt.bar(posiciones, conteoNucleos,
        color=['steelblue', 'darkorange', 'green', 'red'],
        width=0.5)

plt.xticks(posiciones, nombresNucleos)

for i in range(4):
    plt.text(posiciones[i], conteoNucleos[i] + 0.1,
             str(conteoNucleos[i]),
             ha='center',
             fontsize=11)

plt.title('Peticiones pendientes por núcleo al final\nRaspberry Pi 4 Model B (BCM2711)')
plt.xlabel('Núcleo del procesador')
plt.ylabel('Peticiones pendientes')
plt.grid(True, axis='y')
plt.tight_layout()
plt.savefig('grafica_nucleos.png', dpi=150)
plt.show()